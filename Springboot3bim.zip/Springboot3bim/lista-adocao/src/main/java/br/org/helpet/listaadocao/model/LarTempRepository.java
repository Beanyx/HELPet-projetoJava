package br.org.helpet.listaadocao.model;

import org.springframework.data.repository.CrudRepository;

public interface LarTempRepository extends CrudRepository <LarTemp,Long>{
    
    
}

