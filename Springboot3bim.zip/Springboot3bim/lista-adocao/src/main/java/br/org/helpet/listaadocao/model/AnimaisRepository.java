package br.org.helpet.listaadocao.model;

import org.springframework.data.repository.CrudRepository;

public interface AnimaisRepository extends CrudRepository <Animais,Long>{
    
    
}
